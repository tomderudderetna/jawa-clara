<!--zone de drop-->
<div class='target_drop' ondrop='drop(event,' #target_drop')' ondragover='allowDrop(event,'#target_drop')'>
<div class='form-group'>
    <a class='btn btn-default'> <i class='fa fa-plus'></i> </a>
    deplace un bloc de la lists àdroite de ton ecran ici.
</div>