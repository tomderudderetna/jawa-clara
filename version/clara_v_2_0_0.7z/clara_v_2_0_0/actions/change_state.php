<?php
/**
 * Created by PhpStorm.
 * User: jawa_tom
 * Date: 03/10/2017
 * Time: 09:56
 */
require_once "../model/bdd.php";
model\bdd::set_sujet_existe(0);