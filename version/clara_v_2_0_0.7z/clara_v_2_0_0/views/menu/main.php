<div id="main-menu">
    <div class="onglet">Fichier
        <div class="onglet-body">
            <div class="onglet-item">
                <a href="controllers/sujet/create.php">Nouveau</a>
            </div>
            <div class="onglet-item">
                <a onclick="overlay_show('overlay_open')">Ouvrir</a>
            </div>
            <div class="onglet-item">
                <a onclick="save_sujet()">Enregistrer</a>
            </div>
            <div class="onglet-sep"></div>
            <div class="onglet-item">
                <a href="/jawa-clara/clara/controllers/sujet/delete.php?id=<?php echo isset($_GET['id']) ? $_GET['id'] : false;?>">Supprimer</a>
            </div>
            <div class="onglet-sep"></div>
            <div class="onglet-item">
                <a href="index.php">Fermer</a>
            </div>
        </div>
    </div>
    <div class="onglet">Édition
        <div class="onglet-body">
            <div class="onglet-item">
                <a>Couper</a>
            </div>
            <div class="onglet-item">
                <a>Copier</a>
            </div>
            <div class="onglet-item">
                <a>Coller</a>
            </div>
        </div>
    </div>
    <div class="onglet">Affichage
        <div class="onglet-body">
            <div class="onglet-item">
                <a onclick="submitForm()">Preview 1</a>
            </div>
            <div class="onglet-item">
                <a onclick="overlay_show('overlay_preview')">Preview 2</a>
            </div>
        </div>
    </div>
    <a id="btn-valid-form" class="btn btn-primary" target="_blank">Générer</a>
    <a id="btn-download">Télécharger</a>
</div>